# Submission Proyek Analisis Data: Air Quality Dataset

## Setup Environment

```bash
pip install -r requirements.txt
```

## Menjalankan Dashboard

```bash
cd dashboard
streamlit run dashboard.py
```

Dashboard akan terbuka otomatis di browser pada `http://localhost:8501`.